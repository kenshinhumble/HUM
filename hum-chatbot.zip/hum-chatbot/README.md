# FreeModel Chatbot 🤖

AI chatbot menggunakan [FreeModel.dev](https://freemodel.dev) API — OpenAI-compatible, gratis $300 credits.
Dibangun dengan Next.js 14 App Router, streaming SSE, dan dark UI.

## Fitur
- ✅ Streaming real-time (token demi token)
- ✅ Pilih model: gpt-5.5, gpt-5.4, gpt-5.4-mini, gpt-5.3-codex
- ✅ System prompt yang bisa dikustomisasi
- ✅ Markdown rendering (bold, italic, code blocks)
- ✅ Tombol stop streaming
- ✅ API key aman di server-side (tidak terekspos ke client)
- ✅ Dark UI minimalis

---

## Deploy ke Vercel (Gratis)

### 1. Fork / Push ke GitHub

Buat repo baru di GitHub, lalu push semua file ini.

```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/USERNAME/freemodel-chatbot.git
git push -u origin main
```

### 2. Connect ke Vercel

1. Buka [vercel.com](https://vercel.com) → Login dengan GitHub
2. Klik **"Add New Project"**
3. Import repo yang tadi di-push
4. Biarkan semua setting default (Next.js terdeteksi otomatis)
5. **PENTING** — Sebelum deploy, tambahkan Environment Variable:
   - Key: `FREEMODEL_API_KEY`
   - Value: API key kamu dari [freemodel.dev/dashboard/keys](https://freemodel.dev/dashboard/keys)
6. Klik **Deploy** 🚀

### 3. Selesai!

Vercel akan memberikan URL seperti `https://freemodel-chatbot-xxx.vercel.app`.

---

## Development Lokal

```bash
npm install
cp .env.example .env.local
# Isi FREEMODEL_API_KEY di .env.local
npm run dev
```

Buka [http://localhost:3000](http://localhost:3000).

---

## Cara Mendapat API Key FreeModel

1. Daftar di [freemodel.dev](https://freemodel.dev)
2. Verifikasi akun email → dapat 1 bulan Pro gratis + $300 credits
3. Buka [freemodel.dev/dashboard/keys](https://freemodel.dev/dashboard/keys)
4. Buat API key baru

---

## Struktur File

```
freemodel-chatbot/
├── app/
│   ├── layout.js          # Root layout + fonts
│   ├── page.js            # Chat UI (client component)
│   ├── globals.css        # Global styles
│   └── api/
│       └── chat/
│           └── route.js   # API route (server-side, streaming)
├── package.json
├── next.config.js
└── .env.example
```
