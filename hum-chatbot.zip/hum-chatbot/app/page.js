'use client'

import { useState, useRef, useEffect, useCallback } from 'react'

const MODELS = ['gpt-5.5', 'gpt-5.4', 'gpt-5.4-mini', 'gpt-5.3-codex']

const DEFAULT_SYSTEM = 'Kamu adalah HUM (Humble Utility Machine) — asisten AI yang rendah hati, cerdas, dan selalu berusaha memberikan jawaban yang benar-benar berguna. Kamu tidak pernah sombong, selalu jujur jika tidak tahu, dan senang membantu siapa saja. Jawab dengan jelas, ringkas, dan hangat. Gunakan Bahasa Indonesia kecuali user minta bahasa lain.'

// Minimal markdown renderer (bold, italic, code, pre, newlines)
function renderMarkdown(text) {
  // Escape HTML
  let html = text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')

  // Code blocks
  html = html.replace(/```(\w*)\n?([\s\S]*?)```/g, (_, lang, code) =>
    `<pre><code>${code.trim()}</code></pre>`
  )
  // Inline code
  html = html.replace(/`([^`]+)`/g, '<code>$1</code>')
  // Bold
  html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
  // Italic
  html = html.replace(/\*(.+?)\*/g, '<em>$1</em>')
  // Newlines → paragraphs
  html = html
    .split('\n\n')
    .map(p => `<p>${p.replace(/\n/g, '<br/>')}</p>`)
    .join('')

  return html
}

export default function ChatPage() {
  const [messages, setMessages] = useState([])
  const [input, setInput] = useState('')
  const [model, setModel] = useState('gpt-5.4-mini')
  const [systemPrompt, setSystemPrompt] = useState(DEFAULT_SYSTEM)
  const [isStreaming, setIsStreaming] = useState(false)
  const [error, setError] = useState(null)
  const [showSettings, setShowSettings] = useState(false)
  const [tempSystem, setTempSystem] = useState(DEFAULT_SYSTEM)

  const bottomRef = useRef(null)
  const inputRef = useRef(null)
  const abortRef = useRef(null)

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const sendMessage = useCallback(async () => {
    const text = input.trim()
    if (!text || isStreaming) return

    setInput('')
    setError(null)

    const userMsg = { role: 'user', content: text }
    const newMessages = [...messages, userMsg]
    setMessages(newMessages)
    setIsStreaming(true)

    // Placeholder AI message
    setMessages(prev => [...prev, { role: 'assistant', content: '' }])

    abortRef.current = new AbortController()

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: abortRef.current.signal,
        body: JSON.stringify({
          messages: newMessages,
          model,
          systemPrompt,
        }),
      })

      if (!res.ok) {
        const data = await res.json()
        throw new Error(data.error || `HTTP ${res.status}`)
      }

      const reader = res.body.getReader()
      const decoder = new TextDecoder()
      let buffer = ''

      while (true) {
        const { done, value } = await reader.read()
        if (done) break

        buffer += decoder.decode(value, { stream: true })
        const lines = buffer.split('\n')
        buffer = lines.pop() // keep incomplete line

        for (const line of lines) {
          if (!line.startsWith('data: ')) continue
          const data = line.slice(6).trim()
          if (data === '[DONE]') break

          try {
            const parsed = JSON.parse(data)
            const delta = parsed.choices?.[0]?.delta?.content || ''
            if (delta) {
              setMessages(prev => {
                const copy = [...prev]
                copy[copy.length - 1] = {
                  ...copy[copy.length - 1],
                  content: copy[copy.length - 1].content + delta,
                }
                return copy
              })
            }
          } catch {
            // skip malformed chunk
          }
        }
      }
    } catch (err) {
      if (err.name === 'AbortError') {
        // user cancelled — keep partial response
      } else {
        setError(err.message)
        setMessages(prev => prev.slice(0, -1)) // remove empty AI bubble
      }
    } finally {
      setIsStreaming(false)
      inputRef.current?.focus()
    }
  }, [input, messages, model, systemPrompt, isStreaming])

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  }

  const stopStreaming = () => {
    abortRef.current?.abort()
  }

  const clearChat = () => {
    setMessages([])
    setError(null)
  }

  const saveSettings = () => {
    setSystemPrompt(tempSystem)
    setShowSettings(false)
  }

  return (
    <div style={styles.root}>
      {/* Header */}
      <header style={styles.header}>
        <div style={styles.headerLeft}>
          <div style={styles.logo}>
            <span style={styles.logoIcon}>◎</span>
            <div>
              <span style={styles.logoText}>HUM</span>
              <span style={styles.logoSub}>Humble Utility Machine</span>
            </div>
          </div>
          <div style={styles.modelBadge}>
            <span style={styles.modelDot}/>
            {model}
          </div>
        </div>
        <div style={styles.headerRight}>
          {/* Model selector */}
          <select
            value={model}
            onChange={e => setModel(e.target.value)}
            style={styles.select}
            disabled={isStreaming}
          >
            {MODELS.map(m => (
              <option key={m} value={m}>{m}</option>
            ))}
          </select>
          <button
            onClick={() => { setTempSystem(systemPrompt); setShowSettings(true) }}
            style={styles.iconBtn}
            title="Settings"
          >⚙</button>
          <button
            onClick={clearChat}
            style={styles.iconBtn}
            title="Clear chat"
            disabled={isStreaming || messages.length === 0}
          >✕</button>
        </div>
      </header>

      {/* Settings modal */}
      {showSettings && (
        <div style={styles.overlay} onClick={() => setShowSettings(false)}>
          <div style={styles.modal} onClick={e => e.stopPropagation()}>
            <h3 style={styles.modalTitle}>System Prompt</h3>
            <p style={styles.modalDesc}>Atur kepribadian dan konteks AI.</p>
            <textarea
              value={tempSystem}
              onChange={e => setTempSystem(e.target.value)}
              style={styles.systemTextarea}
              rows={6}
              placeholder="Tulis system prompt..."
            />
            <div style={styles.modalActions}>
              <button onClick={() => setShowSettings(false)} style={styles.btnSecondary}>
                Batal
              </button>
              <button onClick={saveSettings} style={styles.btnPrimary}>
                Simpan
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Messages */}
      <main style={styles.messages}>
        {messages.length === 0 && (
          <div style={styles.emptyState}>
            <div style={styles.emptyIcon}>◎</div>
            <p style={styles.emptyTitle}>Halo, aku HUM 👋</p>
            <p style={styles.emptyDesc}>Humble Utility Machine — siap membantu dengan rendah hati. Ketik apapun untuk mulai.</p>
            <div style={styles.suggestionGrid}>
              {['Jelaskan konsep quantum computing', 'Buatkan kode Python untuk sorting', 'Tuliskan cerita pendek fiksi ilmiah', 'Apa perbedaan React dan Vue?'].map(s => (
                <button
                  key={s}
                  style={styles.suggestion}
                  onClick={() => { setInput(s); inputRef.current?.focus() }}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((msg, i) => (
          <div key={i} style={{ ...styles.messageRow, justifyContent: msg.role === 'user' ? 'flex-end' : 'flex-start', animation: 'fadeSlideIn 0.2s ease' }}>
            {msg.role === 'assistant' && (
              <div style={styles.avatar}>AI</div>
            )}
            <div style={msg.role === 'user' ? styles.userBubble : styles.aiBubble}>
              {msg.role === 'assistant' ? (
                msg.content
                  ? <div className="msg-content" dangerouslySetInnerHTML={{ __html: renderMarkdown(msg.content) }} />
                  : <span style={styles.cursor}>▋</span>
              ) : (
                <span style={{ whiteSpace: 'pre-wrap', lineHeight: '1.6' }}>{msg.content}</span>
              )}
            </div>
            {msg.role === 'user' && (
              <div style={{ ...styles.avatar, background: 'var(--accent-dim)', color: 'var(--accent-soft)' }}>U</div>
            )}
          </div>
        ))}

        {error && (
          <div style={styles.errorBox}>
            <strong>Error:</strong> {error}
          </div>
        )}

        <div ref={bottomRef} />
      </main>

      {/* Input area */}
      <footer style={styles.footer}>
        <div style={styles.inputWrapper}>
          <textarea
            ref={inputRef}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ketik pesan... (Enter kirim, Shift+Enter baris baru)"
            style={styles.textarea}
            rows={1}
            disabled={isStreaming}
          />
          {isStreaming ? (
            <button onClick={stopStreaming} style={styles.stopBtn} title="Stop">
              ⏹
            </button>
          ) : (
            <button
              onClick={sendMessage}
              disabled={!input.trim()}
              style={{ ...styles.sendBtn, opacity: input.trim() ? 1 : 0.4 }}
              title="Kirim"
            >
              ➤
            </button>
          )}
        </div>
        <p style={styles.footerNote}>HUM · Powered by <a href="https://freemodel.dev" target="_blank" rel="noreferrer" style={{ color: 'var(--accent-soft)', textDecoration: 'none' }}>FreeModel.dev</a></p>
      </footer>
    </div>
  )
}

const styles = {
  root: {
    display: 'flex',
    flexDirection: 'column',
    height: '100vh',
    maxWidth: '860px',
    margin: '0 auto',
    background: 'var(--bg-base)',
  },
  header: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: '14px 20px',
    borderBottom: '1px solid var(--border)',
    background: 'var(--bg-surface)',
    flexShrink: 0,
  },
  headerLeft: { display: 'flex', alignItems: 'center', gap: '12px' },
  headerRight: { display: 'flex', alignItems: 'center', gap: '8px' },
  logo: { display: 'flex', alignItems: 'center', gap: '10px' },
  logoIcon: { fontSize: '22px', color: 'var(--accent)', lineHeight: 1 },
  logoText: { fontSize: '15px', fontWeight: '700', color: 'var(--text-primary)', letterSpacing: '0.05em', display: 'block', lineHeight: 1 },
  logoSub: { fontSize: '10px', color: 'var(--text-muted)', letterSpacing: '0.04em', display: 'block', marginTop: '2px' },
  modelBadge: {
    display: 'flex', alignItems: 'center', gap: '5px',
    fontSize: '11px', color: 'var(--text-muted)',
    background: 'var(--accent-dim)',
    padding: '3px 8px',
    borderRadius: '99px',
  },
  modelDot: {
    width: '6px', height: '6px',
    borderRadius: '50%',
    background: '#4ade80',
    display: 'inline-block',
  },
  select: {
    background: 'var(--bg-elevated)',
    border: '1px solid var(--border)',
    color: 'var(--text-primary)',
    padding: '5px 8px',
    borderRadius: 'var(--radius-sm)',
    fontSize: '12px',
    cursor: 'pointer',
    outline: 'none',
  },
  iconBtn: {
    background: 'transparent',
    border: '1px solid var(--border)',
    color: 'var(--text-muted)',
    width: '32px', height: '32px',
    borderRadius: 'var(--radius-sm)',
    cursor: 'pointer',
    fontSize: '14px',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    transition: 'all 0.15s',
  },
  messages: {
    flex: 1,
    overflowY: 'auto',
    padding: '24px 20px',
    display: 'flex',
    flexDirection: 'column',
    gap: '16px',
  },
  messageRow: {
    display: 'flex',
    alignItems: 'flex-start',
    gap: '10px',
  },
  avatar: {
    width: '30px', height: '30px', flexShrink: 0,
    borderRadius: 'var(--radius-sm)',
    background: 'var(--bg-elevated)',
    border: '1px solid var(--border)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    fontSize: '11px', fontWeight: '600',
    color: 'var(--accent-soft)',
    marginTop: '2px',
  },
  userBubble: {
    background: 'var(--user-bubble)',
    border: '1px solid rgba(99,102,241,0.25)',
    borderRadius: 'var(--radius-lg) var(--radius-lg) 4px var(--radius-lg)',
    padding: '10px 14px',
    fontSize: '14px',
    lineHeight: '1.6',
    maxWidth: '75%',
    color: 'var(--text-primary)',
    wordBreak: 'break-word',
  },
  aiBubble: {
    background: 'var(--ai-bubble)',
    border: '1px solid var(--border)',
    borderRadius: '4px var(--radius-lg) var(--radius-lg) var(--radius-lg)',
    padding: '12px 16px',
    fontSize: '14px',
    lineHeight: '1.65',
    maxWidth: '80%',
    color: 'var(--text-primary)',
    wordBreak: 'break-word',
  },
  cursor: {
    display: 'inline-block',
    animation: 'pulse 1s infinite',
    color: 'var(--accent)',
  },
  emptyState: {
    display: 'flex', flexDirection: 'column', alignItems: 'center',
    justifyContent: 'center', textAlign: 'center',
    flex: 1, padding: '40px 20px',
    gap: '12px',
  },
  emptyIcon: { fontSize: '40px', color: 'var(--accent)', marginBottom: '4px', opacity: 0.7 },
  emptyTitle: { fontSize: '18px', fontWeight: '600', color: 'var(--text-primary)' },
  emptyDesc: { fontSize: '13px', color: 'var(--text-muted)', maxWidth: '320px' },
  suggestionGrid: {
    display: 'grid', gridTemplateColumns: '1fr 1fr',
    gap: '8px', marginTop: '16px', width: '100%', maxWidth: '500px',
  },
  suggestion: {
    background: 'var(--bg-elevated)',
    border: '1px solid var(--border)',
    color: 'var(--text-muted)',
    padding: '10px 12px',
    borderRadius: 'var(--radius-md)',
    cursor: 'pointer',
    fontSize: '12px',
    textAlign: 'left',
    lineHeight: '1.4',
    transition: 'all 0.15s',
  },
  footer: {
    borderTop: '1px solid var(--border)',
    padding: '14px 20px 16px',
    background: 'var(--bg-surface)',
    flexShrink: 0,
  },
  inputWrapper: {
    display: 'flex', alignItems: 'flex-end', gap: '10px',
    background: 'var(--bg-input)',
    border: '1px solid var(--border)',
    borderRadius: 'var(--radius-md)',
    padding: '10px 12px',
    transition: 'border-color 0.2s',
  },
  textarea: {
    flex: 1, background: 'transparent', border: 'none',
    color: 'var(--text-primary)', fontSize: '14px',
    resize: 'none', outline: 'none',
    lineHeight: '1.5', fontFamily: 'Inter, sans-serif',
    minHeight: '22px', maxHeight: '160px',
  },
  sendBtn: {
    background: 'var(--accent)',
    border: 'none', color: '#fff',
    width: '34px', height: '34px',
    borderRadius: 'var(--radius-sm)',
    cursor: 'pointer',
    fontSize: '14px', flexShrink: 0,
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    transition: 'opacity 0.15s, transform 0.1s',
  },
  stopBtn: {
    background: '#dc2626',
    border: 'none', color: '#fff',
    width: '34px', height: '34px',
    borderRadius: 'var(--radius-sm)',
    cursor: 'pointer',
    fontSize: '14px', flexShrink: 0,
    display: 'flex', alignItems: 'center', justifyContent: 'center',
  },
  footerNote: {
    fontSize: '11px', color: 'var(--text-faint)',
    textAlign: 'center', marginTop: '8px',
  },
  overlay: {
    position: 'fixed', inset: 0,
    background: 'rgba(0,0,0,0.7)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    zIndex: 100, backdropFilter: 'blur(4px)',
  },
  modal: {
    background: 'var(--bg-elevated)',
    border: '1px solid var(--border)',
    borderRadius: 'var(--radius-lg)',
    padding: '24px',
    width: '90%', maxWidth: '500px',
    display: 'flex', flexDirection: 'column', gap: '12px',
  },
  modalTitle: { fontSize: '16px', fontWeight: '600' },
  modalDesc: { fontSize: '13px', color: 'var(--text-muted)' },
  systemTextarea: {
    background: 'var(--bg-input)',
    border: '1px solid var(--border)',
    color: 'var(--text-primary)',
    borderRadius: 'var(--radius-sm)',
    padding: '10px 12px',
    fontSize: '13px',
    fontFamily: 'Inter, sans-serif',
    lineHeight: '1.6',
    resize: 'vertical',
    outline: 'none',
    width: '100%',
  },
  modalActions: { display: 'flex', gap: '8px', justifyContent: 'flex-end' },
  btnSecondary: {
    background: 'transparent',
    border: '1px solid var(--border)',
    color: 'var(--text-muted)',
    padding: '7px 16px',
    borderRadius: 'var(--radius-sm)',
    cursor: 'pointer', fontSize: '13px',
  },
  btnPrimary: {
    background: 'var(--accent)',
    border: 'none', color: '#fff',
    padding: '7px 16px',
    borderRadius: 'var(--radius-sm)',
    cursor: 'pointer', fontSize: '13px', fontWeight: '500',
  },
  errorBox: {
    background: 'rgba(220,38,38,0.1)',
    border: '1px solid rgba(220,38,38,0.3)',
    borderRadius: 'var(--radius-md)',
    padding: '12px 16px',
    fontSize: '13px',
    color: '#fca5a5',
  },
}
