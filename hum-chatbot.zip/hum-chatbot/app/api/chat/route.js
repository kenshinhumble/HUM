export const runtime = 'edge'

const MODELS = [
  'gpt-5.5',
  'gpt-5.4',
  'gpt-5.4-mini',
  'gpt-5.3-codex',
]

export async function GET() {
  return Response.json({ models: MODELS })
}

export async function POST(request) {
  const apiKey = process.env.FREEMODEL_API_KEY

  if (!apiKey) {
    return Response.json({ error: 'FREEMODEL_API_KEY tidak dikonfigurasi di environment variables.' }, { status: 500 })
  }

  let body
  try {
    body = await request.json()
  } catch {
    return Response.json({ error: 'Request body tidak valid.' }, { status: 400 })
  }

  const { messages, model = 'gpt-5.4-mini', systemPrompt } = body

  if (!messages || !Array.isArray(messages)) {
    return Response.json({ error: 'Field messages diperlukan.' }, { status: 400 })
  }

  const allMessages = systemPrompt
    ? [{ role: 'system', content: systemPrompt }, ...messages]
    : messages

  try {
    const upstream = await fetch('https://api.freemodel.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model,
        messages: allMessages,
        stream: true,
        max_tokens: 2048,
      }),
    })

    if (!upstream.ok) {
      const errText = await upstream.text()
      return Response.json(
        { error: `FreeModel API error (${upstream.status}): ${errText}` },
        { status: upstream.status }
      )
    }

    // Forward the SSE stream straight to the client
    return new Response(upstream.body, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'X-Accel-Buffering': 'no',
      },
    })
  } catch (err) {
    return Response.json({ error: `Gagal menghubungi FreeModel API: ${err.message}` }, { status: 502 })
  }
}
